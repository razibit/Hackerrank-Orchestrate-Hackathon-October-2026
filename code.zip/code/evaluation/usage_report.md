# Inference usage report

## Runtime provider and model

- Provider: Microsoft Foundry, using its Azure OpenAI-compatible chat interface.
- Model and deployment reported by the live response metadata and usage checkpoint: `openai--gpt-oss-120b`.
- Authentication values are loaded locally and are not included in source, logs, or this report.
- The user authorized uncapped Foundry GPU-hour use for this challenge. No fixed API-call quota is configured for the active run; per-call retries remain bounded.
- The run configuration uses an accelerator count of 2 based on the user's report. This count and accelerator-hour equivalent are not independently confirmed by Azure billing records.

## Final full target run

The v15 run processed all 518 requests but the CLI did not write a complete target CSV: 267 cases remained unresolved and it exited fail-closed. It saved 251 checkpoint rows (85 `COMPLETE`, 156 `INCOMPLETE`, 10 `NOT_APPLICABLE`). Agent 0 assembled those exact rows into repository-root `output.csv` after the run; it has 251 rows, is missing 267 required cases, and fails the official exact-coverage validator. No cases were guessed into the file, and it is not submission-ready.

| Measurement | Final run |
|---|---:|
| Target requests | 518 |
| Saved / partial CSV rows | 251 (48.46% coverage; not accuracy) |
| Missing / unresolved requests | 267 |
| Provider | Microsoft Foundry |
| Model / deployment | `openai--gpt-oss-120b` |
| API call attempts | 678 |
| Successful / failed attempts | 675 / 3 |
| Retries | 3 |
| Input tokens | 2,078,736 |
| Output tokens | 781,418 |
| Total tokens | 2,860,154 |
| Average tokens per request | 5,521.53 |
| Instrumented elapsed time | 6,967.406 seconds (1.93539 hours) |
| Accelerator-equivalent time | 3.863017 hours (configured count: 2) |
| Provider-reported / measured USD cost | Unavailable / not verified |

The run's first-stop unresolved groups were 130 security-audit retention conditions, 43 workflow-claims-only cases, 35 ungrounded system/resource identifiers, 23 unclassified evidence categories, 23 backup retention conditions, 6 support-message conditions, 4 cases without subject-linked evidence, 1 unresolved data-flow state, and 2 without scoped state proof. No prediction accuracy can be measured for the 518 target rows because organizer labels are unavailable.

## Public sample and custom runs

| Run | Results | Calls | Tokens (input + output) | Instrumented elapsed | Accelerator-equivalent time |
|---|---|---:|---:|---:|---:|
| Sample v15 | 11/32 resolved; 21 blocked | 38 successful; 0 failure/retry | 117,612 + 47,480 = 165,092 | 414.672 seconds | 0.222503 hours |
| Sample v14 comparison | 8/32 resolved; 24 blocked | 41 successful; 0 failure/retry | 119,137 + 48,856 = 167,993 | 445.828 seconds | 0.242662 hours |
| Three independent synthetic cases | 3/3 structurally valid | 3 successful; 0 failure/retry | 6,655 + 2,411 = 9,066 | 25.109 seconds | 0.013911 hours |

Sample labels were evaluated only after prediction generation. The sample metrics apply only to resolved cases and are selection-biased. Custom cases were built independently from target records.

## Cost and measurement limits

Foundry returned no billable USD amount. The user reports a rental rate of $7/hour, but the billing unit and start time are not verified. For scale only, applying $7 to the 1.93539 instrumented wall-clock hours gives about $13.55 total ($0.0262 per request). If instead $7 applies to each configured accelerator-equivalent hour, 3.863017 hours gives about $27.04 total ($0.0522 per request). Neither figure is an actual cost; charges outside the instrumented run are excluded, and the accelerator count is user-configured rather than billing-verified.

The complete output validator rejects root `output.csv` because it lacks 267 cases. These totals describe a completed inference attempt and a partial checkpoint export, not a valid full-dataset submission.

The clean-package smoke run installed the pinned requirements and ran preflight, 114 tests, and extraction-only against the separately supplied dataset. It made no provider calls. Its extraction cache is isolated under the local ignored test directory and is not included in `code.zip`.
