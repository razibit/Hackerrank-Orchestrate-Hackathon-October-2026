# Evaluation report

## Evaluation integrity

Prediction generation reads participant-facing files under `dataset/`. `code/main.py` does not read `sample_output.csv`. Public labels were used only after sample predictions had been saved, by the separate evaluator. No organizer-only truth, generator internals, or case-specific prediction rules were used. The 518-case target has no labels available for evaluation, so no hidden-target accuracy is claimed.

The output contract is fail-closed: the CLI writes a final CSV only after all 518 cases have evidence-grounded predictions and pass the official structural validator. It does not fill unresolved cases with guessed statuses or steps.

## Preflight and tests

Preflight passed for 518 target requests, 32 public sample requests, 15 policy rows, and 94 evidence manifest rows. The supplied evidence includes JSON, logs, PDFs, PNGs, SQL, and text. The current implementation's full unit suite passed **114 tests**:

```powershell
.\.venv\Scripts\python.exe -B -m unittest discover -s code\tests -q
```

The tests cover contract validation, extraction provenance, historical identity, time cutoffs, physical scope, conditional policy, remediation order, strict model parsing, caching, and synthetic safety cases.

## Independent synthetic end-to-end cases

Three independently constructed cases were run through the CLI and output validator. They used synthetic evidence, not target labels.

| Case | Safety property | Result |
|---|---|---|
| `custom-no-delete` | Explicit request forbids deletion | `NOT_APPLICABLE`, no steps |
| `custom-old-alias-replica-flow` | Historical alias; absent primary; remaining replica; active connector | `INCOMPLETE`, seven ordered steps; disables the connector before proposing replica remediation |
| `custom-compliant-tombstone-retained-log` | Compliant tombstone; required retained security record | `COMPLETE`, two evidence-grounded verification steps |

All 3/3 output rows passed the structural validator. The original custom run used 3 successful model calls, 0 failures and 0 retries, 6,655 input plus 2,411 output tokens (9,066 total), and 25.109 seconds of instrumented runtime. The synthetic evidence and commands are documented in `SYNTHETIC_CASES.md`.

## Public sample evaluation

The v15 prediction run processed the 32 supplied sample requests without reading their expected output. It resolved 11 cases; 21 were explicitly left unresolved. The evaluator then compared only the 11 resolved predictions with public labels. These results are a selected subset and are not full-sample accuracy.

| Metric on resolved subset | Result |
|---|---:|
| Coverage | 11/32 (34.38%) |
| Deletion-status accuracy | 10/11 (90.91%) |
| Exact-step precision | 30/59 (50.85%) |
| Exact-step recall | 30/76 (39.47%) |
| Positional-field accuracy | 312/532 (58.65%) |
| Exact ordered-sequence accuracy | 0/11 (0%) |

The 11 resolved sample cases were `case_03`, `case_06`, `case_07`, `case_18`, `case_20`, `case_23`, and `case_25` through `case_28`, plus `case_30`. Every resolved row had at least one exact-step or sequence mismatch. The 21 unresolved cases' first-stop diagnostics group into 7 evidence-category classification failures, 6 unresolved security-log retention conditions, 2 unresolved backup conditions, 3 cases without subject-linked evidence, 2 cases missing grounded system/resource identifiers, and 1 supported only by workflow claims. These categories describe the first stopping point, not necessarily every uncertainty in a case.

A separate cache-only replay tested a one-line planner candidate that retained source citations on all `INCOMPLETE` verification steps. It made no new provider calls and kept coverage/status unchanged at 11/32 and 10/11. The sample evaluator increased exact steps from 30/59 to 32/59, recall from 30/76 to 32/76, and positional fields from 312/532 to 315/532; however, the official partial evaluator rejected three non-empty verification citations in `case_27` because future verification steps in `INCOMPLETE` rows must have an empty `evidence_id`. The candidate was rejected and is not in the package.

Compared with the preceding v14 extraction, v15 resolved 3 additional sample cases (8/32 to 11/32). On their respective resolved subsets, status accuracy moved from 7/8 to 10/11, exact-step precision from 16/39 to 30/59, recall from 16/51 to 30/76, and positional-field accuracy from 192/357 to 312/532. Exact sequence remained 0. An independent paired evaluation found no aggregate exact-step improvement on the eight cases resolved by both runs (16/39 precision, 16/51 recall, 192/357 positional fields, 0/8 exact sequences in each); the aggregate gains came from the three added rows, not better agreement on shared cases. These selected-subset metrics do not establish broad accuracy or predict target performance.

## Changes and diagnosed failure modes

- Trace extraction now pairs only a unique same-operation start and readback completion within a trace, limits inherited context to an identity-field whitelist, rejects conflicting identifiers, and preserves both source-line locators. Generic connection, retry, and recovery rows do not contribute identity context.
- Opaque stable references are compared without normalizing away punctuation, preventing distinct identifiers from being merged.
- Prompts and regression tests clarify that a start event alone is not proof of state and that profile/index state must be grounded in a completed readback.
- The synthetic retained-record fixture now uses the supplied `retention_until` schema, and the tombstone fixture uses the observed participant schema.

Agent 6's read-only review identified one remaining temporal risk: trace-pair selection does not yet require a known start timestamp no later than the completion timestamp. A reversed or unknown order could transfer identity context improperly. This remains a release risk pending a safe regression and implementation update.

PDF/image extraction also has a layout limitation. Native PDF text is extracted when present; scanned pages are flattened through Tesseract text OCR and a narrow set of row/identifier heuristics. The current observation schema does not preserve general table-cell geometry or OCR confidence, and the model receives text rather than page images. The evidence manifest contains 4 PDFs and 11 PNGs, but no corpus-level OCR/layout benchmark was run. Some missing evidence associations may be related to this, but the available measurements do not establish how many cases it affects; unresolved policy and identity cases are separate causes.

## Final target run status

The v15 full target run processed all 518 requests and exited with a fail-closed release block. It saved 251 evidence-grounded rows (85 `COMPLETE`, 156 `INCOMPLETE`, 10 `NOT_APPLICABLE`) and left 267 requests unresolved. The CLI did not write `output.csv`. After the run ended, Agent 0 assembled the 251 saved rows into the repository-root `output.csv` without filling unresolved cases. The file has the exact header and all included rows pass per-row structural, citation-time, and ordering checks, but it is missing 267 required cases and fails the official validator's exact-coverage check. It is a partial internal artifact, not a submission-ready CSV. No hidden-target accuracy is claimed.

The 267 unresolved cases group as follows: 130 unresolved `SECURITY_AUDIT_LOG` retention conditions; 43 cases supported only by workflow claims; 35 cases without grounded system/resource identifiers; 23 model-unclassified evidence categories; 23 unresolved `BACKUP_ARCHIVE` conditions; 6 unresolved `SUPPORT_MESSAGE` conditions; 4 cases without subject-linked evidence; 1 unresolved data-flow state; and 2 cases without scoped state proof. These are first stopping reasons, not hidden-label error counts.

The final measured run used Microsoft Foundry `openai--gpt-oss-120b`: 678 provider attempts (675 successes, 3 failures, 3 retries), 2,078,736 input tokens, 781,418 output tokens, 2,860,154 total tokens, and 6,967.406 seconds. It reached 3.863017 accelerator-equivalent hours using the locally configured count of 2. The provider did not report an actual USD charge. Complete target-output validation failed only on the 267 missing case rows; see the root `output.csv` for the actual partial rows.

The fail-closed behavior is intentional: unresolved evidence was not converted to guessed status, remediation, or citations. Final release remains blocked on a contract-valid `output.csv` covering all 518 requests.

## Fresh package verification

`code.zip` was built from the explicit 41-file manifest and extracted into a fresh directory. A new virtual environment installed the pinned requirements successfully. With the dataset supplied from outside the archive, package preflight passed, all 114 tests passed, and the packaged CLI's extraction-only run processed the evidence into 3,858 observations and 4,011 activity rows. Extraction-only made no model calls. The target run remains in progress, so a fresh full prediction replay is pending the final output/cache state.
