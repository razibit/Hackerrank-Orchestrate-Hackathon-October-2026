# Executed independent synthetic cases

The custom inputs were generated independently of the supplied challenge labels, then passed through the CLI, Microsoft Foundry, the audit engine, and the structural validator. No real deletion was performed. These cases check behavior; they are not sample or hidden-target accuracy measurements.

| Case | Input condition | Executed outcome |
|---|---|---|
| `custom-no-delete` | The person requests a copy and explicitly says not to delete the account or personal information. | `NOT_APPLICABLE`; `steps_json` is empty. |
| `custom-old-alias-replica-flow` | A historical alias identifies one subject; the primary readback is absent; a replica retains a record; an active connector can sync data. | `INCOMPLETE`; seven ordered steps cite the synthetic findings, disable the connector before deleting the replica, and verify both resources and the flow. |
| `custom-compliant-tombstone-retained-log` | A tombstone exposes only its permitted stable subject reference, while a policy-required security log remains within its supplied retention period. | `COMPLETE`; two grounded verification steps confirm the tombstone and retained security record. |

The fixture uses the participant schema fields `account_status=DELETED` and `retention_until`. An earlier fixture version used unsupported synthetic field names and failed closed; it was corrected to match the supplied evidence schema before this passing run.

## Commands

```powershell
.\.venv\Scripts\python.exe -B code\tools\build_synthetic_cases.py --dataset .run\custom_cases_v14\dataset
.\.venv\Scripts\python.exe -B code\main.py --dataset .run\custom_cases_v14\dataset --requests deletion_requests.csv --output .run\custom_cases_v14\predictions.csv --cache-dir .run\custom_cases_v14\cache --run-dir .run\custom_cases_v14\runs --max-model-calls 0 --allow-uncapped-gpu-hours
.\.venv\Scripts\python.exe -B code\tools\validate_output.py .run\custom_cases_v14\predictions.csv --dataset .run\custom_cases_v14\dataset
```

## Measured result

- 3 of 3 rows generated and accepted by the validator.
- 3 provider calls succeeded; 0 failed attempts and 0 retries.
- 6,655 input tokens and 2,411 output tokens, 9,066 total.
- 25.109 seconds recorded client elapsed time; 0.013911 accelerator-equivalent hours using the configured two-accelerator count (the accelerator count is user-reported/configured, not independently verified).
- Dollar cost was unavailable because the deployment's hourly rate was not available in runtime metadata.

The latest full regression suite passed 114 tests, and preflight passed for 518 target requests, 32 sample requests, 15 rules, and 94 evidence files. See `evaluation_report.md` and `usage_report.md` for public-sample and target-run results and limitations.
